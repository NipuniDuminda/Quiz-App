import React, { useState } from "react";

export default function Start({ setUsername }) {
  const [input, setInput] = useState("");

  const handleSubmit = () => {
    setUsername(input);
  };

  return (
    <div className="start">
      <input
        type="text"
        className="startInput"
        placeholder="Enter your name..."
        onChange={(e) => setInput(e.target.value)}
      />
      <button className="startButton" onClick={handleSubmit}>
        Start
      </button>
    </div>
  );
}
