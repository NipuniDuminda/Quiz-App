import React, { useState } from "react";
import Trivia from "./Trivia";

function ParentComponent() {
  // Function to handle correct answer
  const handleCorrectAnswer = () => {
    console.log("Correct answer chosen!");
    // Add your logic for correct answer here
    // For example, you can update the score or move to the next question
  };

  // Function to handle wrong answer
  const handleWrongAnswer = () => {
    console.log("Wrong answer chosen!");
    // Add your logic for wrong answer here
    // For example, you can display a message or deduct points
  };

  // State to track question number
  const [questionNumber, setQuestionNumber] = useState(1);

  // State to track timeout
  const [timeOut, setTimeOut] = useState(false);

  // Sample trivia data
  const triviaData = [
    {
      id: 1,
      question: "What is the capital of France?",
      answers: [
        { text: "London", correct: false },
        { text: "Berlin", correct: false },
        { text: "Paris", correct: true },
        { text: "Rome", correct: false }
      ]
    },
    {
      id: 2,
      question: "Who wrote the play 'Hamlet'?",
      answers: [
        { text: "William Shakespeare", correct: true },
        { text: "Leo Tolstoy", correct: false },
        { text: "Charles Dickens", correct: false },
        { text: "Jane Austen", correct: false }
      ]
    }
  ];

  return (
    <div>
      <h1>Trivia Game</h1>
      <Trivia
        data={triviaData}
        questionNumber={questionNumber}
        setQuestionNumber={setQuestionNumber}
        setTimeOut={setTimeOut}
        correctAnswer={handleCorrectAnswer} // Pass correctAnswer function
        wrongAnswer={handleWrongAnswer} // Pass wrongAnswer function
      />
    </div>
  );
}

export default ParentComponent;
