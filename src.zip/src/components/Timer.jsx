import React, { useState, useEffect } from "react";

export default function Timer({ setTimeOut, questionNumber }) {
  const [seconds, setSeconds] = useState(30);

  useEffect(() => {
    if (seconds === 0) {
      setTimeOut(true);
    }
    const interval = setInterval(() => {
      setSeconds((prevSeconds) => prevSeconds - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [seconds, setTimeOut]);

  useEffect(() => {
    setSeconds(30);
  }, [questionNumber]);

  return <div>{seconds} sec</div>;
}


